package net.mcreator.theworldofthedamnedmod.procedures;

import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.Entity;

import net.mcreator.theworldofthedamnedmod.block.RockFromAfterlifeBlock;
import net.mcreator.theworldofthedamnedmod.TheWorldOfTheDamnedModModElements;

@TheWorldOfTheDamnedModModElements.ModElement.Tag
public class WorldOfTheDamnedPlayerEntersDimensionProcedure extends TheWorldOfTheDamnedModModElements.ModElement {
	public WorldOfTheDamnedPlayerEntersDimensionProcedure(TheWorldOfTheDamnedModModElements instance) {
		super(instance, 8);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure WorldOfTheDamnedPlayerEntersDimension!");
			return;
		}
		if (dependencies.get("x") == null) {
			System.err.println("Failed to load dependency x for procedure WorldOfTheDamnedPlayerEntersDimension!");
			return;
		}
		if (dependencies.get("y") == null) {
			System.err.println("Failed to load dependency y for procedure WorldOfTheDamnedPlayerEntersDimension!");
			return;
		}
		if (dependencies.get("z") == null) {
			System.err.println("Failed to load dependency z for procedure WorldOfTheDamnedPlayerEntersDimension!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure WorldOfTheDamnedPlayerEntersDimension!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		World world = (World) dependencies.get("world");
		world.setBlockState(new BlockPos((int) x, (int) (y - 1), (int) z), RockFromAfterlifeBlock.block.getDefaultState(), 3);
		world.setBlockState(new BlockPos((int) (x - 1), (int) (y - 1), (int) z), RockFromAfterlifeBlock.block.getDefaultState(), 3);
		world.setBlockState(new BlockPos((int) (x + 1), (int) (y - 1), (int) z), RockFromAfterlifeBlock.block.getDefaultState(), 3);
		world.setBlockState(new BlockPos((int) x, (int) (y - 1), (int) (z + 1)), RockFromAfterlifeBlock.block.getDefaultState(), 3);
		world.setBlockState(new BlockPos((int) x, (int) (y - 1), (int) (z - 1)), RockFromAfterlifeBlock.block.getDefaultState(), 3);
		if ((entity instanceof PlayerEntity)) {
			if (entity instanceof PlayerEntity) {
				ItemStack _setstack = new ItemStack(Items.ENDER_PEARL, (int) (1));
				_setstack.setCount((int) 1);
				ItemHandlerHelper.giveItemToPlayer(((PlayerEntity) entity), _setstack);
			}
		}
	}
}
