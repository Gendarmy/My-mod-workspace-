package net.mcreator.theworldofthedamnedmod.procedures;

import net.minecraft.potion.Effects;
import net.minecraft.potion.EffectInstance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.theworldofthedamnedmod.TheWorldOfTheDamnedModModElements;

@TheWorldOfTheDamnedModModElements.ModElement.Tag
public class DriedBurningSeedsFoodEatenProcedure extends TheWorldOfTheDamnedModModElements.ModElement {
	public DriedBurningSeedsFoodEatenProcedure(TheWorldOfTheDamnedModModElements instance) {
		super(instance, 41);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure DriedBurningSeedsFoodEaten!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.FIRE_RESISTANCE, (int) 4200, (int) 0));
	}
}
