package net.mcreator.theworldofthedamnedmod.procedures;

import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;

import net.mcreator.theworldofthedamnedmod.block.GrassOfTheDeceasedBlock;
import net.mcreator.theworldofthedamnedmod.block.DirtOfTheDeceasedBlock;
import net.mcreator.theworldofthedamnedmod.TheWorldOfTheDamnedModModElements;

@TheWorldOfTheDamnedModModElements.ModElement.Tag
public class GrassOfTheDeceasedNeighbourBlockChangesProcedure extends TheWorldOfTheDamnedModModElements.ModElement {
	public GrassOfTheDeceasedNeighbourBlockChangesProcedure(TheWorldOfTheDamnedModModElements instance) {
		super(instance, 44);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("x") == null) {
			System.err.println("Failed to load dependency x for procedure GrassOfTheDeceasedNeighbourBlockChanges!");
			return;
		}
		if (dependencies.get("y") == null) {
			System.err.println("Failed to load dependency y for procedure GrassOfTheDeceasedNeighbourBlockChanges!");
			return;
		}
		if (dependencies.get("z") == null) {
			System.err.println("Failed to load dependency z for procedure GrassOfTheDeceasedNeighbourBlockChanges!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure GrassOfTheDeceasedNeighbourBlockChanges!");
			return;
		}
		int x = (int) dependencies.get("x");
		int y = (int) dependencies.get("y");
		int z = (int) dependencies.get("z");
		World world = (World) dependencies.get("world");
		if ((((world.getBlockState(new BlockPos((int) x, (int) (y + 1), (int) z))).getBlock() == GrassOfTheDeceasedBlock.block.getDefaultState()
				.getBlock())
				|| ((world.getBlockState(new BlockPos((int) x, (int) (y + 1), (int) z))).getBlock() == DirtOfTheDeceasedBlock.block.getDefaultState()
						.getBlock()))) {
			world.setBlockState(new BlockPos((int) x, (int) y, (int) z), DirtOfTheDeceasedBlock.block.getDefaultState(), 3);
		}
	}
}
